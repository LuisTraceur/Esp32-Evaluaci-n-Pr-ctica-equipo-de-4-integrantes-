#include <WiFi.h>
#include <ThingSpeak.h>
#include "DHT.h"

#define DHTPIN 4
#define DHTTYPE DHT11

DHT dht(DHTPIN, DHTTYPE);

const char* ssid = "UAM-ROBOTICA";
const char* password = "m4nt32024uat";

unsigned long channelID = 3292172;
const char* writeAPIKey = "BF0Y4KCYPJKEZIQ2";

WiFiClient client;

void setup() {

  Serial.begin(115200);
  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED) {
    delay(1000);
    Serial.println("Conectando WiFi...");
  }

  Serial.println("WiFi conectado");

  ThingSpeak.begin(client);

  dht.begin();
}

void loop() {

  float temperatura = dht.readTemperature();
  float humedad = dht.readHumidity();

  Serial.print("Temp: ");
  Serial.println(temperatura);

  Serial.print("Humedad: ");
  Serial.println(humedad);

  ThingSpeak.setField(1, temperatura);
  ThingSpeak.setField(2, humedad);

  int x = ThingSpeak.writeFields(channelID, writeAPIKey);

  if(x == 200){
    Serial.println("Datos enviados correctamente");
  } else {
    Serial.println("Error enviando datos");
  }

  delay(20000);
}